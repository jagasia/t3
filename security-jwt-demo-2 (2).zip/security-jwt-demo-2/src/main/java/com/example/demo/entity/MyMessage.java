package com.example.demo.entity;

public class MyMessage {
	private String message;

	public MyMessage(String message) {
		super();
		this.message = message;
	}
	public MyMessage() {}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
