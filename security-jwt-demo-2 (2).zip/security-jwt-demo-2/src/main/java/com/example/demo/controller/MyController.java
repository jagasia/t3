package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.AuthRequest;
import com.example.demo.entity.MyMessage;
import com.example.demo.entity.Token;
import com.example.demo.util.JwtUtil;

@RestController
@CrossOrigin(origins = {"http://localhost:4200","*"})
public class MyController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtil jwtUtil;

	
	@GetMapping("/hi")
	public MyMessage hi()
	{
		MyMessage msg=new MyMessage();
		msg.setMessage("This is fine now");
		return msg;
	}
	
	@GetMapping("/")
	public MyMessage home() {
//		String username=request.getAttribute("username").toString();
		MyMessage msg=new MyMessage();
		msg.setMessage("Hello welcome to spring security jwt demo Logged");
		return msg;
	}

	@PostMapping("/authenticate")
	public Token authenticate(@RequestBody AuthRequest authRequest) throws Exception {
		System.out.println(".............."+authRequest.getUsername());
        try {
        	System.out.println("This is try");
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
            );
        } catch (Exception ex) {
            throw new Exception("inavalid username/password........................................");
        }
        Token token=new Token(jwtUtil.generateToken(authRequest.getUsername()));
		return token;
	}
}
