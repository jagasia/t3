package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoT3JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoT3JpaApplication.class, args);
		System.out.println("Hello world");
	}

}
