package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Department;
import com.example.demo.repository.DepartmentRepository;

@Service
public class DepartmentService {
	@Autowired
	private DepartmentRepository dr;
	
	public Department create(Department department) {
		return dr.save(department);
	}
	public List<Department> read() {
		return dr.findAll();
	}
	public Department read(Long id) {
		Department result=null;
		Optional<Department> temp = dr.findById(id);
		System.out.println(temp);
//		if(!temp.toString().equals("Optional.empty"))
		if(temp.isPresent())
		{
			result=dr.findById(id).get();
		}
		return result;
	}
	public Department update(Department department) {
		return dr.save(department);
	}
	public void delete(Long id) {
		dr.delete(read(id));
	}
	

}
