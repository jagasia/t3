package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.ProductApi;
import com.example.demo.entity.Product;
//import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	@Autowired
	private ProductApi pa;
	
	@GetMapping("/")
//	@ResponseBody
	public String home(ModelMap model)
	{
		List<Product> products = pa.getAllProducts();
		model.addAttribute("product", new Product());
		model.addAttribute("products", products);
		return "index";
	}
	
	@RequestMapping(value = "product", method = RequestMethod.POST, params = "add")
	public String addProduct(Product product, ModelMap model)
	{
		pa.addProduct(product);
		return home(model);
	}
	
	@RequestMapping(value = "product", method = RequestMethod.POST, params = "edit")
	public String editProduct(Product product, ModelMap model)
	{
		pa.modifyProduct(product);
		return home(model);
	}
	
	@RequestMapping(value = "product", method = RequestMethod.POST, params = "delete")
	public String deleteProduct(Long id, ModelMap model)
	{
		pa.removeProduct(id);
		return home(model);
	}
	
	@GetMapping("product/{id}")
	public String findProductById(@PathVariable Long id, ModelMap model)
	{
		Product product = pa.findProductById(id);
		model.addAttribute("product", product);
		List<Product> products = pa.getAllProducts();
		model.addAttribute("products", products);
		return "index";
	}
}
