package com.example.demo;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Product;

@FeignClient(value = "product-api", url = "http://localhost:8080")
public interface ProductApi {
	@PostMapping("/product")
	public int addProduct(@RequestBody Product product);
	@GetMapping("/product")
	public List<Product> getAllProducts();
	@GetMapping("/product/{id}")
	public Product findProductById(@PathVariable Long id);
	@PutMapping("/product")
	public int modifyProduct(@RequestBody Product product);
	@DeleteMapping("/product/{id}")
	public int removeProduct(@PathVariable Long id);
	
	@GetMapping("/product/count")
	public int getProductsCount();
}
