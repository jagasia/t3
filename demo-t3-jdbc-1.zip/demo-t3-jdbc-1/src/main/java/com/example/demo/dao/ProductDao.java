package com.example.demo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.Product;

@Repository
public interface ProductDao {

	int create(Product product);

	List<Product> read();

	Product read(Long id);

	int update(Product product);

	int delete(Long id);

	public int getProductsCount();
}