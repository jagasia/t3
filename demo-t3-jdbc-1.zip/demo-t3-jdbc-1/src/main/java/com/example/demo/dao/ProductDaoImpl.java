package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Product;

@Component
public class ProductDaoImpl implements ProductDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int create(Product product)
	{
		return jdbcTemplate.update("INSERT INTO PRODUCT VALUES (?,?,?)",product.getId(), product.getName(), product.getPrice());
	}
	@Override
	public List<Product> read()
	{
		return jdbcTemplate.query("SELECT * FROM Product", new ProductRowMapper());
	}
	@Override
	public Product read(Long id)
	{
		return jdbcTemplate.queryForObject("SELECT * FROM Product WHERE id=?", new ProductRowMapper(), id);
	}
	@Override
	public int update(Product product)
	{
		return jdbcTemplate.update("UPDATE Product SET name=?, price=? WHERE id=?",product.getName(), product.getPrice(), product.getId());
	}
	@Override
	public int delete(Long id)
	{
		return jdbcTemplate.update("DELETE FROM Product WHERE id=?",id);
	}
	@Override
	public int getProductsCount()
	{
		return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM Product", Integer.class);
	}
	
}
